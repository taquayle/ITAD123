// Group_3 - Theatre Seating.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <iomanip>
#include <fstream>
using namespace std;

const int ROWS = 16;
const int SEATS = 31;

void setSeats(char[ROWS][SEATS]); //To be written by Jon	

void setCost(double[]);	//To be written by Jon




void displaySeats(char[ROWS][SEATS]); //To be written by Sudocham
int displayMenu(char[ROWS][SEATS], double []); //To be written by Sudocham







int main()
{

	char seats[ROWS][SEATS];
	double seatCost[ROWS];

	system("pause");

	setCost(seatCost);

	setSeats(seats);

	do{ displaySeats(seats);
	}while(displayMenu(seats, seatCost));

	cout << "\n\nEnd of Program Reached!\n\n";

	ofstream costOut;
	costOut.open("seatCost.txt");

	for(int i = 1; i < ROWS; i++)
		costOut << seatCost[i] << endl;

	if(costOut != NULL)
		cout << "\n\n SeatCost.txt successfully written";
	else
		cout << "\n\n SeatCost.txt failed to write";

	ofstream seatsOut;
	seatsOut.open("seatAssign.txt");

	for(int i = 1; i < ROWS; i++)
	{
		for(int j = 1; j < SEATS; j++)
			seatsOut << seats[i][j];
		seatsOut << endl;
	}

	if(seatsOut != NULL)
		cout << "\n\n seatsOut.txt successfully written";
	else
		cout << "\n\n seatOut.txt failed to write";

	seatsOut.close();
	costOut.close();
	system("pause");
	return 0;
}

void setSeats(char seats[][SEATS]) //Place holder to input random values
{
	for(int i = 0; i < ROWS; i++)
		for(int j = 0; j < SEATS; j++)
		{
			int tempRand = rand() % 100;
			if(tempRand > 50)
				seats[i][j] = '#';
			else
				seats[i][j] = '*';
		}

}

void setCost(double seatCost[]) //Place holder to input random values
{
	for (int i = 0; i < ROWS; i++)
		seatCost[i] = rand() % 30;

}



void displaySeats(char seats[][SEATS]) //Place holder to determine if function was reached
{
	cout << "\n\nDisplay Seats reached";
}

int displayMenu(char seats[][SEATS], double seatCost[]) //Place holder to determine if function was reached
{
	cout << "\n\nDisplay Menu reached";
	return 0;
}